# GateANN 按选择率分桶分配搜索预算

这是课程基础实验之外的补充实验。核心改动仅在 `policy.py`：为已有 Low、Medium、High 分桶选择不同的 L，然后由 `run.py` 调用原课程 `gateann_adapter.py search`。它属于外部预算配置策略，不是 GateANN C++ 内核优化，也不是逐查询估计选择率的自适应算法。

不修改课程统一参数文件，不重编译系统，不构建新图索引，不改变过滤逻辑、Graph Tunneling 或查询终止条件。使用原来的预构建正式索引和数据。原课程结果保留。

## 1. 实验组

|策略名|Low|Medium|High|
|---|---:|---:|---:|
|fixed320|320|320|320|
|fixed1280|1280|1280|1280|
|bucket|1280|640|320|

预算规则在运行前固定，不根据本次测试 Ground Truth 调整。它们是待检验的初始设置，不是已经找到的最优参数。这里不提供或预设优化收益。

每组、每分桶重复三次，共 27 次独立查询进程。三轮轮换策略顺序；每个分桶中，各策略在第一、第二、第三位置各出现一次。每次调用只传入一个 L，因此不会把同一进程的峰值 RSS 错当成多个独立测量。

所有组固定 threads=1、beamwidth=8、K=10、FullAdj=32、mem-L=0、cache-budget=0；使用课程固定 GateANN 提交 `71e87cbf0e25c0400c0109dd25a64a7c4dccc9dd` 和现有 AIO 构建。

## 2. 文件说明

- `policy.py`：策略核心和执行顺序，可以逐行阅读。
- `run.py`：调用课程适配器，留存证据，校验结果并支持续跑。
- `analyze.py`：再次核对原始证据，生成中位数、最小值和最大值。
- `test_opt.py`：不需要数据和索引的策略测试。
- `integration.json`：你上传的适配器文件哈希与固定系统提交，用于防止接口版本混用。
- `report_section5.md`：缩小后的第 5 章草稿，实测结果待填写。
- `TESTING.md`：这里已经完成的验证和仍需在虚拟机完成的验证。

运行和汇总仅使用 Python 3 标准库，适用于 Ubuntu 22.04 的 Python 3.10。绘图可选，需要 matplotlib。

## 3. 放入课程目录

把下载的 `gateann-bucket-opt-v1.tar.gz` 放到 Ubuntu 的 `~/Downloads/`；如果实际放在“下载”目录或其他目录，替换下面的压缩包路径。

```bash
cd ~/fvs-course-lab
tar -xzf ~/Downloads/gateann-bucket-opt-v1.tar.gz
python3 -m unittest discover -s gateann_bucket_opt -p 'test_*.py' -v
```

解压后新增一个 `gateann_bucket_opt/` 目录。不要用代码包替换 `adapters/` 或 `config/`。

## 4. 正式运行前

关闭或暂停已知的重负载程序，包括宿主机的大量下载、游戏等，并如实记录实际情况。不要仅为这次补充实验改动虚拟机 CPU 或内存分配；如果改动了，就需要记录，并重新测量对应对照组。

```bash
cd ~/fvs-course-lab
bash scripts/check_dataset.sh
bash scripts/check_indexes.sh
python3 gateann_bucket_opt/run.py --experiment-id opt-bucket-01 --dry-run
```

`--dry-run` 会核对课程文件版本和数据头信息，并打印 27 条计划命令；不会启动查询或创建结果目录。数据和索引的完整校验由前两条课程脚本完成。

## 5. 运行 27 次正式查询

```bash
python3 gateann_bucket_opt/run.py --experiment-id opt-bucket-01
```

该命令不需要 sudo。系统和宿主机缓存不主动清理；各组采用同一处理方式，程序缓存参数显式设为 0。脚本记录每次调用前后的虚拟机内存、缓存、负载和进程快照，它们不是持续监控，也不能观测 VMware 宿主机。

如希望同时记录宿主机情况，可以手动说明，例如：

```bash
python3 gateann_bucket_opt/run.py --experiment-id opt-bucket-01 \
  --host-note "在此填写当时实际观察到的宿主机负载情况"
```

两条正式运行命令选一条即可。若没有观察宿主机情况，使用第一条，报告中保持“未记录宿主机负载”，不要填写未确认的状态。

中断或遇到错误后，查看输出指出的日志。保持相同代码、数据路径和实验编号，使用：

```bash
python3 gateann_bucket_opt/run.py --experiment-id opt-bucket-01 --resume
```

续跑会重新验证已完成项，跳过有效结果；失败的原始目录先改名保存，然后重试。改变策略代码、适配器版本或实验计划后应使用新编号，例如 `opt-bucket-02`。

## 6. 汇总与绘图

```bash
python3 gateann_bucket_opt/analyze.py course_runs/optimization/opt-bucket-01
```

全部 27 条结果通过核对后，得到 `summary.csv` 和可阅读的 `result_table.md`。若没有 `status.json` 或结果不足 27 条，先完成或续跑实验。

如已经安装 matplotlib：

```bash
python3 gateann_bucket_opt/analyze.py course_runs/optimization/opt-bucket-01 --plots
```

如果缺少 matplotlib，可在 Ubuntu 安装 `sudo apt install python3-matplotlib` 后重跑绘图命令。绘图额外生成 `policy_comparison.png` 和 `policy_comparison.pdf`。缺少绘图库不影响已保存的实验和 CSV 汇总。

结果目录内容：

|文件或目录|用途|
|---|---|
|settings.json、plan.json|参数、固定预算、版本、完整执行命令和顺序|
|environment.json、state-before/after*.json|缓存策略说明与虚拟机负载快照|
|doctor.log|固定源码提交、编译和二进制文件检查|
|raw/|每次查询的 command.json、run.log、results.csv 证据副本|
|adapter-*.log|课程适配器输出|
|implementation/|运行当时使用的控制脚本副本|
|results.csv|全部独立运行结果及策略标签|
|summary.csv、result_table.md|分策略、分桶的统计汇总|
|status.json|成功完成且通过验证的状态|

## 7. 怎样解释结果

先比较 bucket 与 fixed320，观察 Low/Medium 的 Recall 改善和延迟、I/O 代价；再与 fixed1280 比较，检查是否保留了需要的质量，并减少部分分桶上的搜索开销。Recall 不接近时，不把延迟比写成等质量加速比。

同一分桶中 L 相同的两组执行的是同一搜索配置：Low 的 bucket 与 fixed1280 均为 1280；High 的 bucket 与 fixed320 均为 320。它们之间的小差别只能视作运行波动，不能当作算法收益。这项策略的价值在于在不同分桶之间分配预算。

默认只按分桶报告结果。不要直接平均三个分桶的 QPS 作为整体 QPS，也不要将各桶中位数的简单平均称为“整体测量中位数”。

时延沿用课程适配器 `1000000/QPS`，原始 QPS 可能已取整；`elapsed_seconds` 包含加载初始化，不能替代查询时延。I/O 是程序逻辑计数，RSS 是独立查询进程全生命周期峰值。误差线表示三次最小—最大范围，不是置信区间。

## 8. 把实测材料发回

```bash
cd ~/fvs-course-lab
tar -czf ~/gateann-opt-results.tar.gz -C course_runs/optimization opt-bucket-01
```

该包只包含本次补充实验的结果、代码副本和原始日志，不包含数据集或索引。上传这个包后才能依据真实数值补全第 5 章结论。

## 9. GitHub 提交

在自己的 GitHub 仓库上传本目录的源代码、README、版本说明和测试文件。不要上传数据集、索引、虚拟机文件或把模拟测试数值当成实验结果。实测完成后，可额外上传体积较小的汇总 CSV 和图，并在 README 说明运行环境、复现命令和结果限制。在报告中填入实际存在且能访问的仓库链接。

本包不替你创建或发布 GitHub 仓库。如果老师要求必须修改 C++ 内核，需要另行明确这一外部配置策略是否满足要求。
